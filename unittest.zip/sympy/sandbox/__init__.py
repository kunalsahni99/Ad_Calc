"""
Sandbox module of SymPy.

This module contains experimental code, use at your own risk!

There is no warranty that this code will still be located here in future
versions of SymPy.
"""
